

## [Build an elegant login in Swift](https://www.youtube.com/watch?v=0OqTn3MXaEI&feature=youtu.be)

## Demo

<img src="https://i.imgur.com/EqHGPjg.gif" width="375" height="700">

### What you will learn:
- Auto layout
- Stackviews
