//
//  UIViewController+Extensions.swift
//  Login
//
//  Created by Nikhil Porika
//

import UIKit

extension UIViewController {
    @IBAction func unwind(_ segue: UIStoryboardSegue) {}
}
